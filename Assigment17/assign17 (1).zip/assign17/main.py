from registration_service import (
    RegistrationService,
    InvalidEmailError,
    UnderageError
)

service = RegistrationService()

email = input("Enter email: ")
age = int(input("Enter age: "))

try:

    result = service.register_user(email, age)

    if result:
        print("Registration successful")

except InvalidEmailError as e:

    print(e)

except UnderageError as e:

    print(e)

except AssertionError as e:

    print(e)