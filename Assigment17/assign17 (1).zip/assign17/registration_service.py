import re


class InvalidEmailError(ValueError):

    def __init__(self, email):
        super().__init__(f"Invalid email format: {email}")


class UnderageError(Exception):

    def __init__(self, age):
        super().__init__(f"User age {age} is below minimum age requirement of 18")


class RegistrationService:

    def register_user(self, email: str, age: int) -> bool:

        assert email is not None, "System invariant failed: email cannot be None"

        if email.strip() == "":
            raise InvalidEmailError(email)

        pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"

        if not re.match(pattern, email):
            raise InvalidEmailError(email)

        if age < 18:
            raise UnderageError(age)

        return True
    
    