import pytest
from registration_service import (
    RegistrationService,
    InvalidEmailError,
    UnderageError
)


@pytest.fixture
def service():
    return RegistrationService()


def test_successful_registration(service):

    result = service.register_user("test@example.com", 20)

    assert result is True


def test_invalid_email(service):

    with pytest.raises(InvalidEmailError):

        service.register_user("wrong-email", 20)


def test_underage_user(service):

    with pytest.raises(UnderageError):

        service.register_user("test@example.com", 16)