class ScoreProcessor:

    def process_score_file(self, file_path: str) -> int:

        try:
            file = open(file_path, "r")

            data = file.read().strip()

            score = int(data)

        except FileNotFoundError:

            print("Error: File not found.")
            raise

        except ValueError:

            print("Error: Invalid number format.")
            raise

        else:

            print("Data processed successfully")
            return score * 10

        finally:

            try:
                file.close()
            except:
                pass

            print("File cleanup completed")