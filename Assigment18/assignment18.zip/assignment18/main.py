from score_processor import ScoreProcessor

processor = ScoreProcessor()

score = input("Enter score: ")

with open("score.txt", "w") as file:
    file.write(score)

try:

    result = processor.process_score_file("score.txt")

    print("Final Result:", result)

except Exception as e:

    print("Program Error:", e)